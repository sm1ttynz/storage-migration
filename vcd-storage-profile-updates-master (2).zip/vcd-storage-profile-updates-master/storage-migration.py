#!/usr/bin/env python3
# Pyvcloud Examples
#
# Copyright (c) 2018 VMware, Inc. All Rights Reserved.
#
# This product is licensed to you under the
# Apache License, Version 2.0 (the "License").
# You may not use this product except in compliance with the License.
#
# This product may include a number of subcomponents with
# separate copyright notices and license terms. Your use of the source
# code for the these subcomponents is subject to the terms and
# conditions of the subcomponent's license, as noted in the LICENSE file.
#

# Illustrates vCD login and how to obtain information about the installation.

import requests
import os
import sys
import time
import argparse
import json
import getpass
from pyvcloud.vcd.client import BasicLoginCredentials
from pyvcloud.vcd.client import Client
from pyvcloud.vcd.client import NSMAP
from pyvcloud.vcd.org import Org
from pyvcloud.vcd.vdc import VDC
from pyvcloud.vcd.client import EntityType
from pyvcloud.vcd.vm import VM
from pyvcloud.vcd.vapp import VApp
from pyvcloud.vcd.exceptions import VcdException

class MyLogger():
    def __init__(self):
        self.warning_list = []
        # Define the current file name.
        file_splits = os.path.split(__file__)
        filename = file_splits[-1].split('.')

        # Define log file names
        log_file_name = filename[0] + '-' + \
            time.strftime("%Y%m%d-%H%M%S") + ".log"
        warning_file_name = filename[0] + '-warnings-' + \
            time.strftime("%Y%m%d-%H%M%S") + ".log"

        # log file paths
        self.log_file = './' + log_file_name
        self.warning_file = './' + warning_file_name

    def log(self, log_string):
        with open(self.log_file, mode='a') as log:
            log.write(time.strftime("%Y%m%d-%H:%M:%S | ") + log_string + "\n")

        if "WARNING" in log_string:
            with open(self.warning_file, mode='a') as warning_log:
                warning_log.write(time.strftime("%Y%m%d-%H:%M:%S | ") + log_string + "\n")

        print(log_string)

    def newline(self):
        with open(self.log_file, mode='a') as log:
            log.write("\n")
            print("\n")

class StorageTier():
    '''
    This function is set to define the dict of storage profiles, mapping
    customer values to backend values, to enable the script to translate
    from customer values back to backend values to complete the task.
    '''
    def __init__(self):
        # tiers is defined as Customer_values:Backend_values
        self.tiers = {
            'Storage Tier 1':'Tier1',
            'Storage Tier 2':'Tier2',
            'All Flash Array - Gold':'Tier7',
            'All Flash Array - Diamond':'Tier6'
        }
        self.keys = list(
            map(
                lambda key: key, self.tiers.keys()
                )
            )

    def get_tier(self, tier):
        '''returns the dict value for key'''
        tier_value = self.tiers.get(tier)
        return tier_value


class MyVM():
    '''A worker class to consolidate required data as attributes'''
    def __init__(self, client, vm):
        self.client = client
        self.vm = vm
        self.obj = VM(client=self.client, resource=self.vm)
        self.vm_resources = self.obj.get_resource()
        virtual_hardware = \
            self.obj.list_virtual_hardware_section(
                is_cpu=True,
                is_memory=True,
                is_disk=True,
                is_media=True,
                is_networkCards=True
                )

        # Check for diskspace
        disk_info_list = list(filter(
            lambda item: item.get(
                'diskVirtualQuantityInBytes'
                )
            is not None,
            virtual_hardware
            ))
        self.allocated_disk_GB = 0.0
        self.disks = len(disk_info_list)
        KB = 1024
        for disk in disk_info_list:
            B = disk.get('diskVirtualQuantityInBytes')
            GB = B / (KB ** 3)
            self.allocated_disk_GB += GB

        # Check for snapshots
        snapshot = self.vm_resources.SnapshotSection
        if hasattr(snapshot[0], 'Snapshot'):
            if len(snapshot[0].Snapshot) != 0:
                self.snapshot_exist = True
        else:
            self.snapshot_exist = False

        # exploring spec section
        self.disk_info = []
        self.storage_profile_usage = {}
        if hasattr(self.vm_resources.VmSpecSection, 'DiskSection'):
            if hasattr(self.vm_resources.VmSpecSection.DiskSection,
                       'DiskSettings'):
                for disk_setting in \
                        self.vm_resources.VmSpecSection.DiskSection.\
                        DiskSettings:

                    self.disk_info.append(
                        {'ThinProvisioned': disk_setting.ThinProvisioned,
                         'SizeMB': disk_setting.SizeMb,
                         'StorageProfile': disk_setting.StorageProfile.get('name')}
                        )

            storage_profiles_set = set(
                list(
                    map(
                        lambda disk: disk.get('StorageProfile'), self.disk_info
                        )
                    )
                )

            # For each disk_setting per disk
            for sp in storage_profiles_set:
                sp_disk_info = list(
                    filter(
                        lambda disk: disk['StorageProfile'] == sp,
                        self.disk_info
                        )
                    )
                for disk in sp_disk_info:
                    if self.storage_profile_usage.get(sp) is None:
                        self.storage_profile_usage.update({sp: disk['SizeMB']})
                    else:
                        self.storage_profile_usage[sp] += disk['SizeMB']

        self.is_compliant = self.vm_resources.IsComputePolicyCompliant

        media_attached_list = list(
            filter(
                lambda item: item.get('mediaCdHostResource') is not None,
                virtual_hardware
                )
            )

        if len(media_attached_list) != 0:
            self.media_attached = media_attached_list[0]['mediaCdHostResource']
        else:
            self.media_attached = None
        self.name = self.vm_resources.get('name')
        self.computer_name = self.vm_resources.GuestCustomizationSection.\
            ComputerName

        if hasattr(self.vm_resources, 'Description'):
            self.description = self.vm_resources.Description
        else:
            self.description = ''
        self.os_family = \
            self.vm_resources['{' + NSMAP['ovf'] + '}OperatingSystemSection']\
                .get('{' + NSMAP['vmw'] + '}osType')
        self.os = \
            self.vm_resources['{' + NSMAP['ovf'] + '}OperatingSystemSection']\
            .Description
        if self.vm_resources.get('BootOptions') is not None:
            self.boot_delay = self.vm_resources.BootOptions.BootDelay
            self.enter_bios_setup = \
                self.vm_resources.BootOptions.EnterBIOSSetup
        else:
            self.boot_delay = None
            self.enter_bios_setup = None
        self.storage_profile = self.vm_resources.StorageProfile.get('name')
        self.storage_profiles = set(
            map(
                lambda sp: sp.get('name'), self.obj.list_storage_profile()
                )
            )

    def update_storage_profile(self, target_storage_profile_href):
        try:
            task = self.obj.update_general_setting(
                name=self.name,
                description=str(self.description),
                computer_name=str(self.computer_name),
                boot_delay=self.boot_delay,
                enter_bios_setup=self.enter_bios_setup,
                storage_policy_href=target_storage_profile_href
            )
            return task, "Updating ...."
        except Exception as e:
            return -1, f"Exception encountered when updating vm general \
                settings: {str(e)}"

    def find_ghost_disks(self, source_sp):
        '''
        Return true if any disks are using the source storage profile
        '''
        # reload the VM
        self.obj.reload()
        vm_resources = self.obj.get_resource()
        if hasattr(vm_resources.VmSpecSection, 'DiskSection'):
            if hasattr(vm_resources.VmSpecSection.DiskSection,
                    'DiskSettings'):
                for disk_setting in \
                        vm_resources.VmSpecSection.DiskSection.\
                        DiskSettings:

                    self.disk_info.append(
                        {'StorageProfile': disk_setting.StorageProfile.get('name')}
                        )

        # get list of disks using the source storage policy
        disk_list = list(
            filter(
                lambda disk: source_sp in disk['StorageProfile'],
                self.disk_info
                )
            )
        if len(disk_list) > 0:
            return True
        else:
            return False


def main():

    parser = argparse.ArgumentParser(description='ArgumentParser')
    parser.add_argument(
        '--vcd_host',
        required=True,
        type=str,
        help="fqdn or ip address to the VCD")
    parser.add_argument(
        '--org',
        required=True,
        type=str,
        help="Name of Organistation")
    parser.add_argument(
        '--vapp',
        required=False,
        type=str,
        help="Name of vapp")
    parser.add_argument(
        '--vdc',
        required=True,
        type=str,
        help="Name of VDC")
    parser.add_argument(
        '--user',
        required=True,
        type=str,
        help="Admin user to authenticate to VCD and update VM's")
    parser.add_argument(
        '--source_storage_profile',
        type=str,
        required=True,
        help="Storage profile name which VM's should be migrated from")
    parser.add_argument(
        '--target_storage_profile',
        type=str,
        required=True,
        help="Storage profile name which VM's should be migrated to")
    parser.add_argument(
        '--no_checkmode',
        default=False,
        action='store_true',
        help="Query only")
    parser.add_argument(
        '--silent',
        default=False,
        action='store_true',
        help="Silence user prompts")
    parser.add_argument(
        '--ignore_errors',
        default=False,
        action='store_true',
        help="Ignore VM errors")
    parser.add_argument(
        '--exclude_txt',
        type=str,
        default=None,
        required=False,
        help="Excludes VM's containing exclude_txt in VM name")
    parser.add_argument(
        '--include_txt',
        type=str,
        default=None,
        required=False,
        help="Includes VM's containing include_txt in VM name")
    parser.add_argument(
        '--max_size',
        type=int,
        default=None,
        required=False,
        help="Excludes VM's based on allocated disk size")
    args = parser.parse_args()

    # init logfile
    logger = MyLogger()

    # Collect arguments.
    if len(sys.argv) < 7:
        logger.log(
            f"Usage: python3 {sys.argv[0]} vcd_host --org=org --vdc=vdc \
            --user=username --target_storage_profile=sp_name \
            --source_storage_profile=sp_name --no_checkmode --silent \
            --ignore_errors --exclude_txt=example --max_size")
        sys.exit(1)

    print(args)

    vcd_host = args.vcd_host
    org = args.org
    vdc = args.vdc
    target_vapp = args.vapp
    user = args.user
    password = getpass.getpass("Password:")
    no_checkmode = args.no_checkmode
    silent = args.silent
    ignore_errors = args.ignore_errors
    exclude_txt = args.exclude_txt
    include_txt = args.include_txt
    max_size = args.max_size

    st = StorageTier()
    if st.get_tier(args.source_storage_profile) is None or \
            st.get_tier(args.target_storage_profile) is None:
        logger.newline()
        logger.log("--------------------IMPORTANT--------------------")
        logger.log("--source_storage_profile and --target_storage_profile")
        logger.log(f"must match one of {st.keys}")
        sys.exit(0)
    source_storage_profile = args.source_storage_profile
    target_storage_profile = args.target_storage_profile

    # Disable warnings from self-signed certificates.
    requests.urllib3.disable_warnings()

    # Login. SSL certificate verification is turned off to allow self-signed
    # certificates.  You should only do this in trusted environments.
    logger.newline()
    logger.log(f"Logging in: host={vcd_host}, org={org}, user={user}")
    client = Client(vcd_host,
                    api_version='29.0',
                    verify_ssl_certs=False,
                    log_file='pyvcloud.log',
                    log_requests=True,
                    log_headers=True,
                    log_bodies=True)
    client.set_highest_supported_version()

    # Login to VCD
    try:
        client.set_credentials(BasicLoginCredentials(user, org, password))
    except VcdException as e:
        logger.newline()
        logger.log(f"Error: {e} - Confirm credentials, VCD path and Org name")
        sys.exit(1)

    logger.log("Fetching Org...")
    org = Org(client, resource=client.get_org())
    logger.log(f"Org name: {org.get_name()}")
    logger.log("Fetching VDCs ...")

    # get list of VDC's
    vdcs = org.list_vdcs()

    # Filter VDC's matching the user input spec
    vdc_items = list(
        filter(
            lambda vdc_items: vdc_items.get('name') == vdc, vdcs
            )
        )

    # Ensure only one VDC's returned
    if len(vdc_items) == 1:
        vdc_info = vdc_items[0]
        vdc_name = vdc_info['name']
        vdc_href = vdc_info['href']
        logger.log(f"VDC name: {vdc_name}\n    href: {vdc_href}")

        # Get VDC resources
        logger.log("Getting VDC resources ...")
        vdc = VDC(client, resource=org.get_vdc(vdc_info['name']))
    else:
        logger.log(f"Error | No VDC returned for matching {vdc} in ORG {org}")
        sys.exit(1)

    # Fetch all storage_profiles for vdc
    storage_profiles = vdc.get_storage_profiles()

    logger.newline()
    logger.log("vdc storage profiles:")
    for storage_profile in storage_profiles:
        logger.log(
            f"  - name: {storage_profile.get('name')}\n"
            f"    href: {storage_profile.get('href')}")

    # Create a list of target storage profiles matching the request
    # using the mapping dict declared in teh st object.
    target_storage_profiles = list(filter(
        lambda sp: st.get_tier(target_storage_profile) in sp.get('name'),
        storage_profiles
        ))

    # Check that the target storage profile is in the VDC list of available
    # profiles
    if len(target_storage_profiles) != 1:
        logger.log(
            f"{len(target_storage_profile)} storage profiles matching "
            f"{target_storage_profile}")
        logger.log(
            f"{target_storage_profile} not found in VDC storage profiles.")
        sys.exit(1)
    else:
        # get the name attribute from dict
        target_sp_name = target_storage_profiles[0].get('name')
        # reverse map target storage profile name to the
        # friendly customer name for logging.
        target_sp_friendly_name = list(
            filter(
                lambda key: st.tiers[key] in target_sp_name, st.tiers
                )
            )
        # get href attribute from dict
        target_sp_href = target_storage_profiles[0].get('href')
        logger.newline()
        logger.log("Target storage profile")
        logger.log(
            f"    name: {target_sp_friendly_name[0]}\n"
            f"    href: {target_sp_href}")

    # Fetch vApps
    logger.log("\nFetching Vapps .... \n")
    vapps = vdc.list_resources(EntityType.VAPP)

    # init skipped and completed lists
    skipped_list = []
    completed_list = []
    error_list = []
    ghost_disks = []

    # Loop through each vApp and process each VM
    for vapp in vapps:
        if exclude_txt is not None and exclude_txt in vapp.get('name'):
            skipped_list.append(
                {
                    'vApp': vapp.get('name'),
                    'vm': 'no vms processed',
                    'comment': f'Skipping as VM name includes the exclude_txt'
                }
            )
            continue
                                                              
        if target_vapp is not None and vapp.get('name') != target_vapp:
            continue
        vappx_obj = vdc.get_vapp(name=vapp.get('name'))
        vapp_obj = VApp(client, resource=vappx_obj)
        vms = vapp_obj.get_all_vms()
        logger.log("========================================================")
        logger.log(f"Processing all vms in vApp: {vapp.get('name')} ..... ")
        # Loop through all VM's in vApp process changes
        for vm in vms:
            # Create MyVM instance
            target_vm = MyVM(client=client, vm=vm)
            logger.log("----------------------------------------------------")
            logger.log(f"Processing VM: {target_vm.name}")
            logger.log(
                f"Disk info: {target_vm.disk_info}")

            # reverse map target storage profile name to the friendly customer
            #  name for logging.
            vm_sp_friendly_name = list(
                filter(
                    lambda key: st.tiers[key] in target_vm.storage_profile,
                    st.tiers)
                )

            # Test if storage profile is a supported tier in the profile mapping table
            if len(vm_sp_friendly_name) > 0:
                logger.log(
                    f"VM's storage profile: {vm_sp_friendly_name[0]}")
            else:
                logger.log(
                    f"VM's storage profile is {target_vm.storage_profile} "
                    "which is not in the storage profile mapping table")
                # added to skip vm if it has an unsupported Tier (normally T3)
                skipped_list.append(
                        {
                            'vApp': vapp.get('name'),
                            'vm': target_vm.name,
                            'comment': f'Skipping due to unsupported storage profile of {target_vm.storage_profile}'
                            }
                    )
                continue


            logger.log(
                f"VM's target storage profile: {target_sp_friendly_name[0]}")
            logger.log(
                f"Allocated Disk space: {target_vm.allocated_disk_GB} GB")
            logger.log(
                f"Snapshot present: {target_vm.snapshot_exist}")
            logger.log(
                f"ignore_errors set to: {ignore_errors}")
            if max_size is not None:
                logger.log(
                    f"max_size set to: {max_size}")
            if include_txt is not None:
                logger.log(
                    f"include_txt is set to: {include_txt}")
            if exclude_txt is not None:
                logger.log(
                    f"exclude_txt is set to: {exclude_txt}")

            if not silent:
                print(
                    "Type 'y' to continue, 's' to skip,"
                    "or anything else to abort")
                user_input = input()
                if user_input.lower() == 's':
                    logger.log(
                        f"VM skipped. User input: {user_input}")
                    skipped_list.append(
                        {
                            'vapp': vapp.get('name'),
                            'vm': target_vm.name,
                            'comment': 'Skipping user input'
                        }
                    )
                    continue
                elif user_input.lower() not in ['s', 'y']:
                    logger.log(f"User aborted.  input: {user_input}")
                    sys.exit(0)

            
            # Enable filtering on source storage profiles when
            # managing migrations
            if source_storage_profile is not None and \
                    st.get_tier(source_storage_profile) \
                    not in target_vm.storage_profile:
                logger.log(
                    f"Skipping VM as the current storage profile doesn't \n"
                    f"match: *{st.get_tier(source_storage_profile)}")
                skipped_list.append(
                        {
                            'vApp': vapp.get('name'),
                            'vm': target_vm.name,
                            'comment': f'Skipping due to non-matched targeted storage tier {target_vm.storage_profile}'
                        }
                    )
                continue


            # test if the target storage profile is different to the
            # current storage profile
            if target_sp_name not in target_vm.storage_profile:
                if no_checkmode:
                    logger.log(
                        "\n:----------------Update---------------------")
                    logger.log(
                        f"Updating ....VM {target_vm.name} \n from "
                        f"{vm_sp_friendly_name[0]} to "
                        f"{target_sp_friendly_name[0]}")
                    logger.log(
                        ":--------------------------------------------\n")
                else:
                    logger.log(":----------------Update---------------------")
                    logger.log(
                        "VM would be updated if no_checkmode was 'True'")
                    logger.log("....VM update would be:")
                    logger.log(f"VM={target_vm.name}")
                    logger.log(f"from: {vm_sp_friendly_name[0]}")
                    logger.log(f"to: {target_sp_friendly_name[0]}")
                    logger.log(":--------------------------------------------")
                # placeholder: checkdisk space available.
                # warning prompt for total data being migrated.

                # Include VM's with names containing include_txt
                if include_txt is not None and include_txt not in target_vm.name:
                    skipped_list.append(
                        {
                            'vApp': vapp.get('name'),
                            'vm': target_vm.name,
                            'comment': f'Skipping as VM name does not contain \
                            \'{include_txt}\''
                        }
                    )
                    continue

                # Exclude VM's with names containing exclude_txt
                if exclude_txt is not None and exclude_txt in target_vm.name:
                    skipped_list.append(
                        {
                            'vApp': vapp.get('name'),
                            'vm': target_vm.name,
                            'comment': f'Skipping as VM name includes the exclude_txt \
                            \'{exclude_txt}\''
                        }
                    )
                    continue

                # Exclude VM's based on allocated disk space
                if max_size is not None and target_vm.allocated_disk_GB > max_size:
                    skipped_list.append(
                        {
                            'vApp': vapp.get('name'),
                            'vm': target_vm.name,
                            'comment': f'Skipping as VM allocated diskspace is greater than max_size: {max_size}'
                        }
                    )
                    continue

                # Check-VM is compliant
                if not target_vm.is_compliant:
                    logger.log(
                        f"WARNING | Unable to update VM: {target_vm.name}"
                        "due to compliant state. Compliance status: "
                        f"{target_vm.is_compliant}")
                    skipped_list.append(
                        {
                            'vapp': vapp.get('name'),
                            'vm': target_vm.name,
                            'comment': 'Skipping due to compliance state'
                            }
                    )
                    continue

                # Check Media is not attached
                if target_vm.media_attached is not None:
                    logger.log(
                        f"WARNING | VM: {target_vm.name} has media attached. "
                        "Unable to handle VM updates with attached media. "
                        f"Media: {target_vm.media_attached}")
                    skipped_list.append(
                        {
                            'vapp': vapp.get('name'),
                            'vm': target_vm.name,
                            'comment': 'Skipping due to attached media'
                            }
                    )
                    continue

                # Check whether there ar multiple storage profiles attached
                if len(target_vm.storage_profiles) > 1:
                    logger.log(
                        f"WARNING | VM: {target_vm.name} has "
                        f"{len(target_vm.storage_profiles)} storage profiles"
                        "which will need to be updated outside of this script."
                        f"Storage profiles are: {target_vm.storage_profiles}")
                    skipped_list.append(
                        {
                            'vApp': vapp.get('name'),
                            'vm': target_vm.name,
                            'comment': 'Skipping due to multiple storage profiles'
                            }
                    )
                    continue

                if not no_checkmode:
                    logger.log(f"no_checkmode set to {no_checkmode} and "\
                        "therefore will not make any changes, only report "\
                        "what would have updated.")
                else:
                    task, msg = target_vm.update_storage_profile(target_sp_href)
                    if task == -1:
                        logger.log(msg)

                        # Exit if ignore errors is not set
                        if not ignore_errors:
                            sys.exit(1)

                        # Log the VM error and continue to the next VM
                        error_list.append(
                            {
                                'vApp': vapp.get('name'),
                                'vm': target_vm.name,
                                'error': msg,
                                'log_msg': 'Exception encountered when updating vm general settings'
                            }
                        )
                        continue
                    current_status = ""
                    while client.get_task_monitor().get_status(task=task) not in \
                            ['error', 'canceled', 'aborted', 'success']:
                        time.sleep(5)
                        # get status
                        task_status = client.get_task_monitor().get_status(
                            task=task)
                        # check if current status has changed
                        if task_status == current_status:
                            continue
                        current_status = task_status
                        # log status
                        logger.log(
                            f"VM: {target_vm.name} updating.  Status: {task_status}")

                    result = client.get_task_monitor().wait_for_success(
                        task=task)

                    completed_list.append(
                        {'vapp': vapp.get('name'), 'vm': target_vm.name})
            else:
                logger.log('No update required .....')

 
            # Check for ghost hard disks.
            # Hard disks where a storage policy has been assigned
            # at the hard disk level

            source_sp = st.get_tier(source_storage_profile)
            ghost_disk_present = target_vm.find_ghost_disks(
                source_sp=source_sp
                )
            if ghost_disk_present:
                ghost_disks.append(
                    {
                        'vapp': vapp.get('name'),
                        'vm': target_vm.name,
                        'comment': 'Hard disk/s storage policy needs to '
                        'be manually migrated'
                    }
                )


    logger.newline()
    logger.log(
        "-------------------------------------------------------------")
    logger.log("Skipped VM's")
    logger.log(
        "-------------------------------------------------------------")
    skipped_items = {'skipped_items': skipped_list}
    logger.log(json.dumps(skipped_items, sort_keys=True, indent=2))

    logger.newline()
    logger.log(
        "-------------------------------------------------------------")
    logger.log("Completed VM's")
    logger.log(
        "-------------------------------------------------------------")
    completed_items = {'completed_items': completed_list}
    logger.log(json.dumps(completed_items, sort_keys=True, indent=2))

    logger.newline()
    logger.log(
        "-------------------------------------------------------------")
    logger.log("VM's with ghost disks")
    logger.log(
        "-------------------------------------------------------------")
    ghost_disk_items = {'ghost_disks': ghost_disks}
    logger.log(json.dumps(ghost_disk_items, sort_keys=True, indent=2))

    logger.newline()
    logger.log(
        "-------------------------------------------------------------")
    logger.log("VM's with errors")
    logger.log(
        "-------------------------------------------------------------")
    error_items = {'Error_items': error_list}
    logger.log(json.dumps(error_items, sort_keys=True, indent=2))
    # Log out.
    logger.log("Logging out")
    client.logout()


if __name__ == '__main__':
    main()
